-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 3.36.49.201    Database: dancing_go
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_seq` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `email` varchar(512) NOT NULL,
  `email_verified_yn` varchar(1) NOT NULL,
  `gameover_cnt` bigint DEFAULT NULL,
  `modified_at` datetime(6) NOT NULL,
  `password` varchar(128) NOT NULL,
  `profile_image_url` varchar(512) NOT NULL,
  `provider_type` varchar(20) NOT NULL,
  `role_type` varchar(20) NOT NULL,
  `total_play_cnt` bigint DEFAULT NULL,
  `total_score` bigint DEFAULT NULL,
  `user_id` varchar(64) NOT NULL,
  `user_nickname` varchar(255) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  PRIMARY KEY (`user_seq`),
  UNIQUE KEY `UK_a3imlf41l37utmxiquukk8ajc` (`user_id`),
  UNIQUE KEY `UK_cr59axqya8utby3j37qi341rm` (`user_nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'2021-10-06 10:17:18.099000','jaewshim94@gmail.com','Y',1,'2021-10-06 10:17:18.099000','NO_PASS','https://lh3.googleusercontent.com/a/AATXAJxRAZHMBX7YneNIGKm7A9HN1x1LiFgtjjtprORT=s96-c','GOOGLE','USER',1,79,'106401753908668757418','jeus','심재우'),(3,'2021-10-06 16:18:16.530000','sxxnweek@gmail.com','Y',1,'2021-10-06 16:18:16.530000','NO_PASS','https://lh3.googleusercontent.com/a-/AOh14GjzKlBCfQhoe1sfjNYHSSrDYGfEAq6arTp4vHOE=s96-c','GOOGLE','USER',1,78,'117154352607372629256','sxxnweek','뚱별'),(4,'2021-10-06 17:55:48.075000','dymin01@gmail.com','Y',1,'2021-10-06 17:55:48.075000','NO_PASS','https://lh3.googleusercontent.com/a/AATXAJwPiV9Yh7OKBEDITSwguS_KMqldTsQ-K2JgfLuM=s96-c','GOOGLE','USER',1,80,'101522943862543379474','정은교','민동엽'),(5,'2021-10-06 17:55:50.416000','shkim2000@gmail.com','Y',4,'2021-10-06 17:55:50.416000','NO_PASS','https://lh3.googleusercontent.com/a/AATXAJxmvCP-sjBYTh9zzctugNIu7T9bgY5hePWDw8Bl=s96-c','GOOGLE','USER',1,87,'114006067136510520776','승현승현승현','김승현'),(6,'2021-10-06 17:55:55.290000','gyoforit@gmail.com','Y',0,'2021-10-06 17:55:55.290000','NO_PASS','https://lh3.googleusercontent.com/a-/AOh14GjFl4pnAs29HzMUmcp_osDsjOq4puzSAbtY_Z2S=s96-c','GOOGLE','USER',8,93,'107885123414979442368','댄머싱신','Eungyo Jeong'),(40,'2021-10-07 10:13:33.871000','NO_EMAIL','Y',0,'2021-10-07 10:13:33.871000','NO_PASS','','KAKAO','USER',0,0,'1917858546','심쮸','심재우'),(41,'2021-10-07 10:28:06.837000','dymin01@naver.com','Y',0,'2021-10-07 10:28:06.837000','NO_PASS','https://ssl.pstatic.net/static/pwe/address/img_profile.png','NAVER','USER',1,83,'H627mpbJTzbQNNnPxgrR3jzZiyE4shN_nHzxyA3WpmY','민동','등신'),(42,'2021-10-07 18:05:23.386000','NO_EMAIL','Y',0,'2021-10-07 18:05:23.386000','NO_PASS','','KAKAO','USER',0,0,'1940513935','싸피랩','싸피랩'),(43,'2021-10-07 19:02:52.587000','NO_EMAIL','Y',0,'2021-10-07 19:02:52.587000','NO_PASS','','KAKAO','USER',1,90,'1920362744','순주순주','순주'),(44,'2021-10-07 19:03:29.802000','ksj96226@naver.com','Y',0,'2021-10-07 19:03:29.802000','NO_PASS','https://phinf.pstatic.net/contact/20191002_177/1570013114395SDyPe_PNG/__%3B.png','NAVER','USER',1,91,'ypWTDFadNDEG2J5mUkmlXl-OIBnLIf-5dQn2HzQsGgU','밥먹쟈아아아','뚠'),(45,'2021-10-07 20:05:52.988000','a01058009521@gmail.com','Y',0,'2021-10-07 20:05:52.988000','NO_PASS','https://lh3.googleusercontent.com/a/AATXAJzYnBtrk6xKRl1PHF6EXRx42zDI3OdsDLI9eI0W=s96-c','GOOGLE','USER',0,0,'101823959936051301647','5반스파이','이지민'),(46,'2021-10-08 01:31:21.873000','NO_EMAIL','Y',0,'2021-10-08 01:31:21.873000','NO_PASS','','KAKAO','USER',0,0,'1941043884',NULL,'신동윤');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-08  1:32:20
