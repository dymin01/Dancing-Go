<template>
  <div>
    <h1>랭킹모드</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>