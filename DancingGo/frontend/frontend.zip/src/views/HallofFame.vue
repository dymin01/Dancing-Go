<template>
  <div>
    <h1>명예의전당</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>